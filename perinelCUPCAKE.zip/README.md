# perinelCUPCAKE

### CONSIGNES 

- ce n'est pas responsive !OK
- nom du dossier nom_de_familleCUPCAKE !OK
- un dossier img et un dossier css !OK
- nom de la page nom_de_famille_cupcake.html !OK
- feuille de style en externe nom_de_famille_cupcake.css !OK
- en flex ou en float (ou les deux combinés) ! EN FLEX!OK
- un reset dans le css !OK
- bien indenter !OK
- bien commenter !OK

### LES TEXTES 
​
CAKE MY DAY
711 Boylston St.
Boston, MA 01720
​
Every day we make 100 cupcakes of a special flavor not on the menu. Order it by name & it's free! You have to act fast though, when all 100 are gone the deal is done for the day. (Limit 1 per customer.) 
P.S. We post the flavor name on Twitter about 30 minutes before the website, so follow us to get a head start.
Today's free cupcake
October 9
Triple Caramel
36 left !
​
Why do you do this ?
We freshly bake more than 50 varieties of cupcakes a day including standars such as Red Velvet, Carrot and Devil's Food as wekk crazy esoteric (but delicious) flavors such as Milshake, Hot Chocolate and Cannoli. We're pretty sure that once you get a taste of what we have to offer you'll be back for more. It's that Simple!

Sample of our not-so-free wares
Strawberry Chocolate<br> Chocolate cake filled and froster with chocolate fudge, topped with strawberry frosting and sprinkled with chocolate stars

Carrot Cheesecake<br> Carrot cake with cheesecake baked in topped with vanilla cream cheese frosting and chocolate star.

Peanut Butter<br> Vanilla caka filled with peanut butter frosting, topped with peanut butter and chocolate cream cheese frosting and peanut butter chips.